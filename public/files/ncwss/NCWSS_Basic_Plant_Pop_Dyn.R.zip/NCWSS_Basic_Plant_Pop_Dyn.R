##########################################################################
# Simple Population dynamics demographic model for annual plant species
# sequential set of difference equations with no density dependence,
# immigration = emigration
# Adapted from code written by Dr. Bruce Maxwell Montana State University 
##########################################################################

endt=10  #Number of years to simulate population dynamics

#Output Table with cell addresses and times
Table1 <- matrix(0, nrow=endt+1, ncol=7)
colnames(Table1) <- c("t","Seeds","Seedlings","Mature","Seed Produced", "dN/dt","Lambda")
Table1[,1] <- c(0:endt)

#Demographic parameters
estab <- .2    #Seed to seedling establishment
sdls <- .1     #Survival of seedlings to mature plants 
sppM <- 600   #Seed produced per Mature plant 
ssrv <- .22     #Seed survival in the seed bank from 1 year to next
sr <- .5       #Proportion of seed produced remaining in the cell (immigration = emigration)

#Initial (t=0) population stage values (densities)
Seeds <- 100
Sdl <- as.integer(estab*Seeds)
Mature <- as.integer(Sdl*sdls)
SP <- as.integer(sppM*Mature)  #Seeds produced per pop

Table1[1,2] <- Seeds
Table1[1,3] <- Sdl
Table1[1,4] <- Mature
Table1[1,5] <- SP
Table1[1,6] <- NA
Table1[1,7] <- NA
#Table1  #Print Table1 to screen

for(t in 1:endt){
   Seeds <- Table1[t,2]
   Sdl <- Seeds * estab
   Mature <- Sdl * sdls
   SP <- Mature * sppM
   Seeds <- ((Seeds-Sdl) + SP*sr)*ssrv

   Table1[t+1,2] <- as.integer(Seeds)
   Table1[t+1,3] <- as.integer(Sdl)
   Table1[t+1,4] <- as.integer(Mature)
   Table1[t+1,5] <- as.integer(SP)
   Table1[t+1,6] <- as.integer(Seeds - Table1[t,2])   #dN/dt
   Table1[t+1,7] <- Seeds/Table1[t,2]     #Lambda

} #end t
Table1
plot(Table1[,1],Table1[,4], type="b", xlab="time", ylab="Density of mature plants (No./m^2)",cex=1.5,lwd=1.5,cex.lab=1.5,cex.axis=1.5)


############################################################
# Add density dependence to the model.
###########################################################
endt=20  #Number of years to simulate population dynamics

#Output Table with cell addresses and times
Table1 <- matrix(0, nrow=endt+1, ncol=7)
colnames(Table1) <- c("t","Seeds","Seedlings","Mature","Seed Produced", "dN/dt","Lambda")
Table1[,1] <- c(0:endt)

#Demographic parameters
estab <- .2    #Seed to seedling establishment
sdls <- .23     #Survival of seedlings to mature plants 
sppmax <- 600   #Maximum seed produced per Mature plant 
i <- 0.1       #Asymptotic response shape parameter
a <- .78       #Asymptotic response shape parameter
#Show the density dependent response
tmp <- matrix(0, nrow=100, ncol=2)
colnames(tmp) <- c("Density", "sppM")
tmp[,1] <- 1:100
tmp[,2] <- sppmax*(1-(i*tmp[,1])/(1 + i*tmp[,1]/a))
plot(tmp[,1],tmp[,2], xlab="Plant density", ylab="Seed produced per plant",cex=1.5,lwd=1.5,cex.lab=1.5,cex.axis=1.5)

ssrv <- .22     #Seed survival in the seed bank from 1 year to next
sr <- .5       #Proportion of seed produced remaining in the cell (immigration = emigration)

#Initial (t=0) population stage values (densities)
Seeds <- 100
Sdl <- as.integer(estab*Seeds)
Mature <- as.integer(Sdl*sdls)
sppM <- sppmax*(1-(i*Mature)/(1 + i*Mature/a))
SP <- as.integer(sppM*Mature)  #Seeds produced per pop

Table1[1,2] <- Seeds
Table1[1,3] <- Sdl
Table1[1,4] <- Mature
Table1[1,5] <- SP
Table1[1,6] <- NA
Table1[1,7] <- NA
#Table1  #Print Table1 to screen

for(t in 1:endt){
   Seeds <- Table1[t,2]
   Sdl <- Seeds * estab
   Mature <- Sdl * sdls
   sppM <- sppmax*(1-(i*Mature)/(1 + i*Mature/a))
   SP <- Mature * sppM
   Seeds <- ((Seeds-Sdl) + SP*sr)*ssrv

   Table1[t+1,2] <- as.integer(Seeds)
   Table1[t+1,3] <- as.integer(Sdl)
   Table1[t+1,4] <- as.integer(Mature)
   Table1[t+1,5] <- as.integer(SP)
   Table1[t+1,6] <- as.integer(Seeds - Table1[t,2])   #dN/dt
   Table1[t+1,7] <- Seeds/Table1[t,2]     #Lambda

} #end t
Table1
plot(Table1[,1],Table1[,4], type="b", xlab="time", ylab="Density of mature plants (No./m^2)",cex=1.5,lwd=1.5,cex.lab=1.5,cex.axis=1.5)


####################################################################
# Add stochasticity to the density dependent model
###################################################################
endt=20  #Number of years to simulate population dynamics

#Output Table with cell addresses and times
Table1 <- matrix(0, nrow=endt+1, ncol=7)
colnames(Table1) <- c("t","Seeds","Seedlings","Mature","Seed Produced", "dN/dt","Lambda")
Table1[,1] <- c(0:endt)

#Demographic parameters
estab <- matrix(rnorm(endt,.2,.01), nrow=endt, ncol=1)    #Seed to seedling establishment
sdls <- matrix(rnorm(endt,.23,.01), nrow=endt, ncol=1)    #Survival of seedlings to mature plants 
sppmax <- matrix(rnorm(endt,600,160), nrow=endt, ncol=1)  #Maximum seed produced per Mature plant 
i <- matrix(0.1, nrow=endt, ncol=1)                       #Asymptotic response shape parameter
a <- matrix(.78, nrow=endt, ncol=1)                       #Asymptotic response shape parameter
ssrv <- matrix(rnorm(endt,.22,.01), nrow=endt, ncol=1)    #Seed survival in the seed bank from 1 year to next
sr <- matrix(.5, nrow=endt, ncol=1)                       #Proportion of seed produced remaining in the cell (immigration = emigration)

#Initial (t=0) population stage values (densities)
Seeds <- 100
Sdl <- as.integer(estab[1,1]*Seeds)
Mature <- as.integer(Sdl*sdls[1,1])
sppM <- sppmax[1,1]*(1-(i[1,1]*Mature)/(1 + i[1,1]*Mature/a[1,1]))
SP <- as.integer(sppM*Mature)  #Seeds produced per pop

Table1[1,2] <- Seeds
Table1[1,3] <- Sdl
Table1[1,4] <- Mature
Table1[1,5] <- SP
Table1[1,6] <- NA
Table1[1,7] <- NA

for(t in 1:endt){
   Seeds <- Table1[t,2]
   Sdl <- Seeds * estab[t,1]
   Mature <- Sdl * sdls[t,1]
   sppM <- sppmax[t,1]*(1-(i[t,1]*Mature)/(1 + i[t,1]*Mature/a[t,1]))
   SP <- Mature * sppM
   Seeds <- ((Seeds-Sdl) + SP*sr[t,1])*ssrv[t,1]

   Table1[t+1,2] <- as.integer(Seeds)
   Table1[t+1,3] <- as.integer(Sdl)
   Table1[t+1,4] <- as.integer(Mature)
   Table1[t+1,5] <- as.integer(SP)
   Table1[t+1,6] <- as.integer(Seeds - Table1[t,2])   #dN/dt
   Table1[t+1,7] <- Seeds/Table1[t,2]     #Lambda

} #end t
Table1
plot(Table1[,1],Table1[,4], type="b", xlab="time", ylab="Density of mature plants (No./m^2)",cex=1.5,lwd=1.5,cex.lab=1.5,cex.axis=1.5)
